package com.kataChallenge.common;

import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Constants 
{
	public static final int invalidInput=-1;
	public static final int validInput=100;
	public static final int totalDices=5;
	public static final int diceMinValue=1;
	public static final int diceMaxValue=6;
	public static final int yahtzeeScore=50;
			
	static Logger logger = Logger.getLogger("MyLog");  
    static FileHandler fh;  

    static{
        try 
        {  
        	fh = new FileHandler("MyLogFile.log");  
            logger.addHandler(fh);        
            SimpleFormatter formatter = new SimpleFormatter();  
            fh.setFormatter(formatter);  
            logger.info("My first log");
        }catch(Exception e){
        	e.printStackTrace();
        }

    }

}
