package com.kataChallenge.common;


import java.util.Scanner;

import com.kataChallenge.userInput.UserInput;

public class Main 
{
		public static void main(String args[])
		{
			System.out.println("\tWelcome to Yehtzee");
			UserInput userInput=new UserInput();
			userInput.execute();
		}
}
